package prog1.gyakorlo.cats.solution;

import prog1.gyakorlo.cats.solution.exceptions.NotImplementedException;
import prog1.gyakorlo.cats.solution.places.Supermarket;

/**
 * Egy embert leíró osztály.
 */
public class Human {
    /**
     * Az ember konstruktora.
     * @param name az ember neve
     * @param money az ember pénze
     * @param favouriteSupermarket az ember kedvenc boltja
     */
    public Human(String name, int money, Supermarket favouriteSupermarket) {
        throw new NotImplementedException();
    }

    /**
     * Az ember nevének lekérdezésére szolgáló metódus.
     * @return az ember neve
     */
    public String getName() {
        throw new NotImplementedException();
    }

    /**
     * Az ember pénzének lekérdezésére szolgáló metódus.
     * @return az ember pénze
     */
    public int remainingMoney() {
        throw new NotImplementedException();
    }

    /**
     * Azt a folyamatot jelképezi, hogy az ember macskaeledelt vásárol a kedvenc boltjában.
     * A boltban a macskaeledelt "Cat food"-nak hívják, tehát ebből szeretnénk megfelelő mennyiségnyit vásárolni.
     * Nyilván csak egész mennyiségű macskaeledel vásárolható.
     * Amennyiben nem lehetséges a teljes mennyiséget beszerezni (valamilyen oknál fogva), akkor nem veszünk semmit.
     * @param amount a vásárolni kívánt macskaeledel mennyisége
     * @return igaz, ha sikeres volt a vásárlás; hamis különben
     */
    public boolean buyFood(int amount) {
        throw new NotImplementedException();
    }

    /**
     * Azt a folyamatot jelképezi, hogy az ember a saját kertjeiben megeteti a macskáit.
     * Az ember folyamatosan járja be a kertjeit (megvásárlásuk sorrendjében). A hamarabb megvásárolt kertben lévő
     * macskákat hamarabb eteti meg.
     * A macskák etetése a kertbe való csatlakozásuk sorrendjében történik, tehát a legrégebben a kertben lévő
     * macska etetése történik meg leghamarabb.
     * Amennyiben nincs elegendő macskaeledelünk egy macska megetetéséhez, akkor megpróbáljuk a boltban beszerezni a szükséges
     * mennyiséget (ne többet). Egy etetés alkalmával többször is el tud menni a boltba.
     * Természetesen a korábbi etetésekkor vásárolt macskaeledel is használható, illetve egy dobozból több macska is
     * megetethető.
     * Ha nem sikerül, akkor a macska etetése sikertelen. Ilyenkor a többi macska etetésével kell folytatnunk.
     */
    public void feedCats() {
        throw new NotImplementedException();
    }
}
