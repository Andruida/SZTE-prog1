/**
 * Ennek a package-nek kell tartalmaznia az összes osztályt, amelyet a kiértékelés során szeretnénk használni.
 */
package prog1.gyakorlo.cats.solution;
