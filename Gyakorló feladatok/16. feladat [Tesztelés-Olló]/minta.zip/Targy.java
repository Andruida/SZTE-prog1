
import java.util.Arrays;

/**
 * Egy tetszőleges tárgyat reprezentáló osztály
 */
public class Targy {
    /**
     * A tárgy neve
     */
    private String nev;

    /**
     * A tárgy erőssége
     * 0 - a tárgy a lehető legkisebb tépésre kettéválik - például egy vékony írólap
     * 50 - A tárgyat egy erősebb, sepciális ollóval simán el lehet vágni  - például vékony fémlemez
     * 100 - A tárgyat nem lehet elvágni ollóval, csak speciális készülékkel - például egy 1 köbméteres betonkocka
     * Bármilyen 100-tól nagyobb érték esetén a tárgy nem átvágható.
     */
    private int erosseg;

    /**
     * A tárgyat befoglaló téglalap mérete.
     * <p>
     * Az egyszerűség kedvéért a programban mindig csak a szembenézeti vetületét tároljuk a tárgynak (vagyis csak egy 2 dimenziós, n*m méretet)
     */
    public int[] meret;

    public Targy(String nev, int erosseg, int meretX, int meretY) {
        this.nev = nev;
        this.erosseg = erosseg;
        this.meret = new int[]{meretX, meretY};
    }

    public Targy(String nev, int erosseg, int meretX) {
        this.nev = nev;
        this.erosseg = erosseg;
        this.meret = new int[]{meretX, meretX};
    }

    /**
     * Átvágható egy tárgya egy speciális, erre a célra kialíktott eszközzel.
     *
     * @return true, ha átvágható (erősség <= 100)
     * false egyébként
     */
    public boolean atvaghato() {
        return erosseg <= 100;
    }

    /**
     * A tárgy átvágása egy valamilyen ollóval.
     * A visszatérés akkor lesz hamis, ha a tárgy átvágása sikertelen.
     * Sikertelen az átvágás, ha az olló nem képes átvágni a tárgyat, vagy ha a tárgy mérete túl kicsi lenne (0*0)
     *
     * @return true, ha sikeres az átvágás.
     */
    public boolean atvag(Ollo o) {
        if (this.meret[0] / 2 == 0 || this.meret[1] / 2 == 0) {
            return false;
        }
        if (o.kepesAtvagni(this)) {
            this.meret[0] = this.meret[0] / 2;
            this.meret[1] = this.meret[1] / 2;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Targy{" +
                "nev='" + nev + '\'' +
                ", erosseg=" + erosseg +
                ", meret=" + Arrays.toString(meret) +
                '}';
    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public int getErosseg() {
        return erosseg;
    }

    public void setErosseg(int erosseg) {
        this.erosseg = erosseg;
    }

    public int[] getMeret() {
        return meret;
    }

    public void setMeret(int[] meret) {
        this.meret = meret;
    }
}
