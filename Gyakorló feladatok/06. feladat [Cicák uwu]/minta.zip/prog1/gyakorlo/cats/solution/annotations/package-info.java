/**
 * A programhoz készült annotációkat tartalmazó package.
 */
package prog1.gyakorlo.cats.solution.annotations;
