
/**
 * Ollót reprezentáló osztály
 */
public class Ollo {
    /**
     * Az olló élessége.
     */
    private int elesseg;

    /**
     * Az utoljára átvágott tárgy neve.
     */
    private String utoljaraAtvagott;

    /**
     * Tudjuk, hogy csak egy adott dolgot vágtak-e egy adott ollóval.
     */
    public boolean csakEgyDolgotVagtakVele;

    public Ollo(int elesseg) {
        this.elesseg = elesseg;
        this.utoljaraAtvagott = null;
        this.csakEgyDolgotVagtakVele = true;
    }

    public Ollo() {
        this.elesseg = 100;
        this.utoljaraAtvagott = null;
        this.csakEgyDolgotVagtakVele = true;
    }

    /**
     * Képes-e átvágni egy olló egy adott tárgyat
     *
     * @param targy az átvágni kívánt tárgy
     * @return true, ha képes átvágni.
     */
    public boolean kepesAtvagni(Targy targy) {
        if (targy == null) {
            return false;
        }
        return targy.atvaghato() && elesseg >= targy.getErosseg();
    }

    /**
     * Tárgy átvágása.
     *
     * @param targy az átvágni kívánt tárgy
     * @return true, ha sikeres az átvágás.
     */
    public boolean atvag(Targy targy) {
        boolean sikeresAtvagas = targy.atvag(this);
        // át tudtuk vágni
        if (sikeresAtvagas) {
            if (utoljaraAtvagott == null) {
                utoljaraAtvagott = targy.getNev();
            }
            // Beállítjuk, hogy csak egy dolgot vágtunk-e az adott ollóval.
            if (!targy.getNev().equals(utoljaraAtvagott)) {
                csakEgyDolgotVagtakVele = false;
            }
            utoljaraAtvagott = targy.getNev();
            elesseg -= targy.getErosseg() / 2;
        }
        return sikeresAtvagas;
    }

    /**
     * Kicsorbult-e az adott olló
     *
     * @return true, ha kicsorbult (vagyis az élessége 0).
     */
    public boolean kicsorbult() {
        return elesseg == 0;
    }

    /**
     * Az olló élezése.
     * <p>
     * Egy jó mester ránézésre látja, milyen mértékű csiszolásra van szüksége az ollónak.
     * Amennyiben túlságosan erősen csiszolnak egy ollót, kicsorbul, és életlen lesz.
     * Amennyiben pont jól csiszolják meg, a korábbi élességének 1.5-szörösére élesedik.
     * Minden más esetben az élesség 1.25-szörösére
     *
     * @param erohatas az élezés ereje
     */
    public void elezes(int erohatas) {
        // ha túl nagy erővel próbálják meg csiszolni az ollót, akkor kicsorbul
        if (100 - elesseg < erohatas) {
            elesseg = 0;
            return;
        }
        // ha pont a szükséges erővel csiszolják
        if (100 - elesseg == erohatas) {
            elesseg = (int) Math.min(100, elesseg * 1.5);
        } else {
            elesseg = (int) Math.min(100, elesseg * 1.25);
        }
    }

    @Override
    public String toString() {
        return "Ollo{" +
                "elesseg=" + elesseg +
                ", utoljaraAtvagott='" + utoljaraAtvagott + '\'' +
                ", csakEgyDolgotVagtakVele=" + csakEgyDolgotVagtakVele +
                '}';
    }

    public int getElesseg() {
        return elesseg;
    }

    public void setElesseg(int elesseg) {
        this.elesseg = elesseg;
    }

    public String getUtoljaraAtvagott() {
        return utoljaraAtvagott;
    }

    public void setUtoljaraAtvagott(String utoljaraAtvagott) {
        this.utoljaraAtvagott = utoljaraAtvagott;
    }

    public boolean isCsakEgyDolgotVagtakVele() {
        return csakEgyDolgotVagtakVele;
    }

    public void setCsakEgyDolgotVagtakVele(boolean csakEgyDolgotVagtakVele) {
        this.csakEgyDolgotVagtakVele = csakEgyDolgotVagtakVele;
    }
}
