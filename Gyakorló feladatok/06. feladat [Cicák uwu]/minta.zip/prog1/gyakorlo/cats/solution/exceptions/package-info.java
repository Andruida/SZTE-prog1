/**
 * A program során előforduló kivételeket tartalmazó package.
 */
package prog1.gyakorlo.cats.solution.exceptions;
